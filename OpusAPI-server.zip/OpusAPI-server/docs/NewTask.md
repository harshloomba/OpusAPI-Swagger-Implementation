
# NewTask

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taskId** | **Long** |  | 
**createdAt** | **String** |  | 
**completedAt** | **String** |  | 
**callbackUrl** | **String** |  | 
**type** | **String** |  | 
**status** | **String** |  | 
**instruction** | **String** |  | 
**urgency** | **String** |  | 



