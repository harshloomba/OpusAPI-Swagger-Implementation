# DefaultApi

All URIs are relative to *http://api.opusapi.com/api/v1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancelTaskById**](DefaultApi.md#cancelTaskById) | **GET** /tasks/{taskId}/cancel | 
[**createCategorizationTask**](DefaultApi.md#createCategorizationTask) | **POST** /tasks/categorization | 
[**createPhoneCallTask**](DefaultApi.md#createPhoneCallTask) | **POST** /tasks/phonecall | 
[**createTranscriptionTask**](DefaultApi.md#createTranscriptionTask) | **POST** /tasks/transcription | 
[**getAllTasks**](DefaultApi.md#getAllTasks) | **GET** /tasks | 
[**getTaskById**](DefaultApi.md#getTaskById) | **GET** /tasks/{taskId} | 


<a name="cancelTaskById"></a>
# **cancelTaskById**
> cancelTaskById(taskId)



cancel the task

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Long taskId = 789L; // Long | Cancel task
try {
    apiInstance.cancelTaskById(taskId);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#cancelTaskById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **taskId** | **Long**| Cancel task |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="createCategorizationTask"></a>
# **createCategorizationTask**
> List&lt;NewTask&gt; createCategorizationTask(instruction, attachment, categories, callbackUrl, attachmentType, urgency, status)



Created categorization task

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String instruction = "instruction_example"; // String | A plaintext string explaining the instructions for the task.
String attachment = "attachment_example"; // String | Attachment
List<String> categories = Arrays.asList("categories_example"); // List<String> | categories assigned to attachment
String callbackUrl = "callbackUrl_example"; // String | A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details.
String attachmentType = "attachmentType_example"; // String | Attachment type
String urgency = "urgency_example"; // String | A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time.
String status = "status_example"; // String | The status of the task
try {
    List<NewTask> result = apiInstance.createCategorizationTask(instruction, attachment, categories, callbackUrl, attachmentType, urgency, status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createCategorizationTask");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **instruction** | **String**| A plaintext string explaining the instructions for the task. |
 **attachment** | **String**| Attachment |
 **categories** | [**List&lt;String&gt;**](String.md)| categories assigned to attachment |
 **callbackUrl** | **String**| A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details. |
 **attachmentType** | **String**| Attachment type | [optional]
 **urgency** | **String**| A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time. | [optional]
 **status** | **String**| The status of the task | [optional] [enum: pending, completed, cancelled]

### Return type

[**List&lt;NewTask&gt;**](NewTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="createPhoneCallTask"></a>
# **createPhoneCallTask**
> List&lt;NewTask&gt; createPhoneCallTask(callbackUrl, instruction, phoneNumber, attachmentType, attachment, entityName, script, urgency, fields)



schedule the phone call

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String callbackUrl = "callbackUrl_example"; // String | A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details.
String instruction = "instruction_example"; // String | A plaintext string explaining the instructions for the task.
String phoneNumber = "phoneNumber_example"; // String | Phone number
String attachmentType = "attachmentType_example"; // String | Attachment type
String attachment = "attachment_example"; // String | Attachment
String entityName = "entityName_example"; // String | The name of the entity which corresponds to the person or business of the phone number
String script = "script_example"; // String | An optional script to be shown the the worker as they make the phone call. You should use this if you've already optimized a script for phone calling.
String urgency = "urgency_example"; // String | A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time.
List<String> fields = Arrays.asList("fields_example"); // List<String> | A dictionary corresponding to the fields to be recorded. Keys are the keys you'd like the fields to be returned under, and values are descriptions to be shown to human workers
try {
    List<NewTask> result = apiInstance.createPhoneCallTask(callbackUrl, instruction, phoneNumber, attachmentType, attachment, entityName, script, urgency, fields);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createPhoneCallTask");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **callbackUrl** | **String**| A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details. |
 **instruction** | **String**| A plaintext string explaining the instructions for the task. |
 **phoneNumber** | **String**| Phone number |
 **attachmentType** | **String**| Attachment type |
 **attachment** | **String**| Attachment |
 **entityName** | **String**| The name of the entity which corresponds to the person or business of the phone number |
 **script** | **String**| An optional script to be shown the the worker as they make the phone call. You should use this if you&#39;ve already optimized a script for phone calling. | [optional]
 **urgency** | **String**| A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time. | [optional]
 **fields** | [**List&lt;String&gt;**](String.md)| A dictionary corresponding to the fields to be recorded. Keys are the keys you&#39;d like the fields to be returned under, and values are descriptions to be shown to human workers | [optional]

### Return type

[**List&lt;NewTask&gt;**](NewTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="createTranscriptionTask"></a>
# **createTranscriptionTask**
> List&lt;NewTask&gt; createTranscriptionTask(instruction, attachment, callbackUrl, attachmentType, urgency, status)



Created transcription Task

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String instruction = "instruction_example"; // String | A plaintext string explaining the instructions for the task.
String attachment = "attachment_example"; // String | Attachment
String callbackUrl = "callbackUrl_example"; // String | A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details.
String attachmentType = "attachmentType_example"; // String | Attachment type
String urgency = "urgency_example"; // String | A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time.
String status = "status_example"; // String | The status of the task
try {
    List<NewTask> result = apiInstance.createTranscriptionTask(instruction, attachment, callbackUrl, attachmentType, urgency, status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createTranscriptionTask");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **instruction** | **String**| A plaintext string explaining the instructions for the task. |
 **attachment** | **String**| Attachment |
 **callbackUrl** | **String**| A string of the URL that should be POSTed once the task is completed for the response data. See the Callback section for more details. |
 **attachmentType** | **String**| Attachment type | [optional]
 **urgency** | **String**| A string describing the urgency of the response. One of immediate, day, or week, where immediate is a 15-minute response time. | [optional]
 **status** | **String**| The status of the task | [optional] [enum: pending, completed, cancelled]

### Return type

[**List&lt;NewTask&gt;**](NewTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllTasks"></a>
# **getAllTasks**
> List&lt;Task&gt; getAllTasks()



Retrieve all tasks

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    List<Task> result = apiInstance.getAllTasks();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getAllTasks");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Task&gt;**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getTaskById"></a>
# **getTaskById**
> Task getTaskById(taskId)



Get a single task

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Long taskId = 789L; // Long | return the requested task
try {
    Task result = apiInstance.getTaskById(taskId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getTaskById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **taskId** | **Long**| return the requested task |

### Return type

[**Task**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

